
/**********************************************************************
* � 2006 Microchip Technology Inc.
*
* FileName:        main_rtc.c
* Dependencies:    p24HJ256GP610.h
* Processor:       PIC24H
* Compiler:        MPLAB� C30 v2.01 or higher
*
* SOFTWARE LICENSE AGREEMENT:
* Microchip Technology Inc. (�Microchip�) licenses this software to you
* solely for use with Microchip dsPIC� digital signal controller
* products. The software is owned by Microchip and is protected under
* applicable copyright laws.  All rights reserved.
*
* SOFTWARE IS PROVIDED �AS IS.�  MICROCHIP EXPRESSLY DISCLAIMS ANY
* WARRANTY OF ANY KIND, WHETHER EXPRESS OR IMPLIED, INCLUDING BUT NOT
* LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
* PARTICULAR PURPOSE, OR NON-INFRINGEMENT. IN NO EVENT SHALL MICROCHIP
* BE LIABLE FOR ANY INCIDENTAL, SPECIAL, INDIRECT OR CONSEQUENTIAL
* DAMAGES, LOST PROFITS OR LOST DATA, HARM TO YOUR EQUIPMENT, COST OF
* PROCUREMENT OF SUBSTITUTE GOODS, TECHNOLOGY OR SERVICES, ANY CLAIMS
* BY THIRD PARTIES (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF),
* ANY CLAIMS FOR INDEMNITY OR CONTRIBUTION, OR OTHER SIMILAR COSTS.
*
* REVISION HISTORY:
*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* Author            Date      Comments on this revision
*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* Richard Fischer   07/14/05  Initial Release
* Priyabrata Sinha  01/27/06  Ported to non-prototype devices 
* Priyabrata Sinha  01/30/06  Added config macros
*
*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
*
* ADDITIONAL NOTES:  
*
* Simple demo program showing a RTC and ADC conversion on the LCD
* DMA code is included here but not fully tested.
*
* C30 Optimization Level: -O1
*
**********************************************************************/

#include "p24HJ256GP610a.h"
#include "lcd.h"
#include "common.h"

_FOSCSEL(FNOSC_PRIPLL);
_FOSC(FCKSM_CSDCMD & OSCIOFNC_OFF & POSCMD_XT);
_FWDT(FWDTEN_OFF);

void Update_LCD( void );
const char mytext[] =  "   PIC24H Demo  ";
const char mytext1[] = "Press S3 to cont";
const char time_msg[] = "Time 00: 00: 00 ";
const char adc_msg1[] = " RP5 = 0.00 Vdc  ";
const char accn_msg1[] = "                 ";

// Using internal FRC oscillator at 8MHz
// Fosc = Fin * (DIVISOR<8:0> + 2 / ((PRESCLR<4:0> +2) * (PLLPOST<1:0> +1) )
// DIVISOR<8:0> bits located in PLLFBF SFR ---> (PLL Multiplier)
// PLLPOST<1:0> bits located in CLKDIV SFR ---> (PLL VCO output divide)
// PRESCLR<4:0> bits located in CLKDIV SFR ---> (PLL Phase Detector input divide)

char nibtohex(unsigned char v)  // convert the lower 4 bits into a hex digit
{
  v&=0xf;
  if (v<10) return (v+0x30);
  return (v-10+0x41);
}

unsigned char accndata[6];		// save the x,y,z data
char accnstr[16];				// string for output
void getACCn(void)
{ 	
  int i;
  unsigned char testval;
  unsigned int value;

			I2S();				// start the I2C
			I2send(0x38);		// write to acceleration chip address
			I2send(0x00);		// select this internal reg (CHANGE here to read another reg)
			I2SR();				// restart I2C
			I2send(0x39);		// ask to read from acceleration chip
	    	testval=I2GET(0);	// get value from reg number specified above
			I2P();				// stop the I2C

			// The next bit checks to see if a new valid set of data by looking at reg 0 in chip
			I2S();I2send(0x38);I2send(0x00);I2SR();I2send(0x39);
	    	i=I2GET(0);I2P();
		    if (i & 8)	// yes new data
				{
				I2S();I2send(0x38);I2send(0x01);I2SR();I2send(0x39); // read the x,y,z data from reg 1 onwards
				for (i=0;i<=5;i++)
					{accndata[i]=I2GET(i!=5);
					}
			    I2P();
				// now show on lcd
				line_2();
                accnstr[0]=nibtohex(testval>>4);
                accnstr[1]=nibtohex(testval);
// display first value in hex - adjust if neg and show -
                value=accndata[0];
				value=(value<<4) | (accndata[1]>>4);
				if (value & 0x800) 
					{
						accnstr[2]='-';
						value=0x1000-value;
					}
					else accnstr[2]=' ';
                accnstr[3]=nibtohex(value>>8);
                accnstr[4]=nibtohex(value>>4);
                accnstr[5]=nibtohex(value);

// display second value in hex - adjust if neg and show -
                value=accndata[2];
				value=(value<<4) | (accndata[3]>>4);
				if (value & 0x800) 
					{
						accnstr[6]='-';
						value=0x1000-value;
					}
					else accnstr[6]=' ';
                accnstr[7]=nibtohex(value>>8);
                accnstr[8]=nibtohex(value>>4);
                accnstr[9]=nibtohex(value);

// display third value in hex - adjust if neg and show -
                value=accndata[4];
				value=(value<<4) | (accndata[5]>>4);
				if (value & 0x800) 
					{
						accnstr[10]='-';
						value=0x1000-value;
					}
					else accnstr[10]=' ';
                accnstr[11]=nibtohex(value>>8);
                accnstr[12]=nibtohex(value>>4);
                accnstr[13]=nibtohex(value);
				puts_lcd( (char*) &accnstr[0], 14 );
				}
}


int main ( void )
{
	/* Initialize some general use variables */
	hours, minutes, seconds = 0;
	rtc_lcd_update = 0;

        //The settings below set up the oscillator and PLL for 16 MIPS as
        //follows:
        //            Crystal Frequency  * (DIVISOR+2)
        // Fcy =     ---------------------------------
        //              PLLPOST * (PRESCLR+2) * 4	
        PLLFBD = 0x00A0;
        CLKDIV = 0x0048;
 
	/* set LEDs (D3-D10/RA0-RA7) drive state low */
	LATA = 0xFF00; 
	/* set LED pins (D3-D10/RA0-RA7) as outputs */
	TRISA = 0xFF00; 
	
	/* Initialize LCD Display */
	Init_LCD();

	/* Welcome message */
	home_clr();
	puts_lcd( (char*) &mytext[0], sizeof(mytext) -1 );
	line_2();
	puts_lcd( (char*) &mytext1[0], sizeof(mytext1) -1 );
		
	/* wait here until switch S3 is pressed */
	while ( PORTDbits.RD6 );
		    
  	/* Initialize Timer 1 for 32KHz real-time clock operation */
    Init_Timer1();

    /* Initial LCD message for TOD */
	home_clr();
	puts_lcd( (char*) &time_msg[0], sizeof(time_msg) -1 );
 	line_2();
	puts_lcd( (char*) &adc_msg1[0], sizeof(adc_msg1) -1 );
          
    /* Initialize ADC  */
    Init_ADC();
    
    /* Initialize DMA Channel 0 */
//    Init_DMAC0();
      initi2c();
// the next bit sets up the accn chip
	I2S();I2send(0x38);I2send(0x2a);I2send(0x20);//50Hz nonactive  
                               I2send(0x2);I2P();
	I2S();I2send(0x38);I2send(0x2a);I2send(0x21);//50Hz active 
                               I2P();
    /* Infinite Loop */
    while ( 1 ) 
    { 
      /* check if time to update LCD with TOD data */  
      if ( rtc_lcd_update ) 
	  {
		 hexdec( hours );
		 Update_LCD();
		 rtc_lcd_update = 0;
         
      }	
	if (!PORTDbits.RD13 ) // show acceleration data when s4 pressed
		{
	 	line_2();
		puts_lcd( (char*) &accn_msg1[0], sizeof(accn_msg1) -1 );
		getACCn();
		}
      /* check if time to update LCD with ADC data */
  	  if ( adc_lcd_update ) 
  	  {
	if (!PORTDbits.RD6 ) // show pot when s3 pressed
		{
	 	line_2();
		puts_lcd( (char*) &adc_msg1[0], sizeof(adc_msg1) -1 );
       	 line_2();
		 advolt( temp1 );
       	 cursor_right();
       	 cursor_right();
       	 cursor_right();  
       	 cursor_right();
       	 cursor_right();
       	 cursor_right();
       	 cursor_right();
		 lcd_data( adones );
       	 cursor_right();
	  	 lcd_data( adtens );
	  	 lcd_data( adhunds );	
	     adc_lcd_update = 0;
  		}       
	  }
	};
}


/*---------------------------------------------------------------------
  Function Name: Update_LCD
  Description:   Update LCD for real-time clock data
  Inputs:        None
  Returns:       None
-----------------------------------------------------------------------*/
void Update_LCD( void )
{

   	/* position LCD cursor at column, row */
  	home_it();
    cursor_right();
    cursor_right();
    cursor_right();
    cursor_right();
    cursor_right();
	lcd_data(tens + 0x30);
	lcd_data(ones + 0x30);
    
    hexdec( minutes );
    /* position LCD cursor at column, row */
	cursor_right();
    cursor_right();
	lcd_data(tens + 0x30);
	lcd_data(ones + 0x30);
	 
  	hexdec( seconds );
	/* position LCD cursor at column, row */
	cursor_right();
    cursor_right();
	lcd_data(tens + 0x30);
	lcd_data(ones + 0x30);
   
}



#include "p24hj12GP201.h"
#include <stdio.h>
#include <stdlib.h>

/*
Config part --do not touch
*/

_FBS(  BSS_NO_BOOT_CODE & BWRP_WRPROTECT_OFF )
_FGS( GCP_OFF & GWRP_OFF )
_FOSCSEL( FNOSC_FRCPLL & IESO_OFF )
_FOSC( FCKSM_CSDCMD & IOL1WAY_OFF & OSCIOFNC_ON & POSCMD_NONE)
_FWDT( FWDTEN_OFF )
_FPOR( FPWRT_PWR128 & ALTI2C_OFF )
_FICD(ICS_PGD2 & JTAGEN_OFF)

#define BYTE unsigned char

#define I2C_max_address 24
// max number of echo ticks
#define limit 1024
// how many ticks to skip while waiting for Ultrasonic RX to settle
#define settle 70
// The next variable is the sensitivity to pulses.... decreases over echo distance
#define iguard 128
// the default value of the working freq.... loaded into a timer
#define defaultfreq 94


// image of the I2C regs
BYTE i2c_buffer[I2C_max_address];
BYTE I2Cfirst=1;
BYTE I2Cadress = 0;

volatile BYTE i2c_change[I2C_max_address];  // bit set if the value in a reg has changed

volatile int echo,state,max,min;
volatile char leftright;      // are we doing the left or right channel
volatile char gotval,gotmax;
volatile int gecho,gmax;
int lgecho,rgecho,lgmax,rgmax;
char nl,nr;
volatile char getscan,pendscan;
volatile int echoval[257];				// a block of scaned data
char inhibit;

volatile int wavepoint;

volatile int ra,rb,ia,ib;	// used to aproximate mag of signal after decoding real and imag

void SetupPORTS(void)  // sets up the ports and A/D and I2C
						// think before you change
{
PR3=defaultfreq;
T3CON=0x8000;
AD1PCFGL=0xff33;

AD1CON1=0x0544;  
AD1CON2=0x0006; // interupt on every other sample
AD1CSSL=0x0000;
AD1CON3=0x0302;
AD1CHS123=0x0000;
AD1CHS0=0x0303;
AD1CON1=0x8544;

	I2C1CON=0x1000;
	I2C1ADD=0xB8>>1; //set slave address
	I2C1MSK=0x000; //set slave address
	I2C1CONbits.I2CEN=1; //enable i2c slave on port 1


/*
ANPORT
15 14 13 12 11 10  9  8  7  6  5  4  3  2  1  0
                         Y  Y        Y  Y  

PORTA
15 14 13 12 11 10  9  8  7  6  5  4  3  2  1  0
                                  U  O  O PGC PGD
                                  O  x  x I  O
                                                
PORTB
15   14 13 12 11 10   9   8  7  6  5  4  3  2   1  0
L    A                       x        U  x  x  V2 Venv
I    I  O   O  O  O   O   O  O  O  O  O  o  o   I  I

B9 = SDA   B8 = SCL
*/
	LATA = 0x0000; 
	TRISA = 0x0002;
	LATB = 0x0000; 
	TRISB = 0xc003; 
    ODCB=0;


//*************************************
// Unlock Registers
//*************************************
asm volatile ( "mov #OSCCON, w1 \n"
"mov #0x46, w2 \n"
"mov #0x57, w3 \n"
"mov.b w2, [w1] \n"
"mov.b w3, [w1] \n"
"bclr OSCCON, #6");
//***************************
// Configure Input Functions
// (See Table 9-1)
//***************************


//***************************
// Configure Output Functions
// (See Table 9-2)
//***************************

asm volatile ( "mov #OSCCON, w1 \n"
"mov #0x46, w2 \n"
"mov #0x57, w3 \n"
"mov.b w2, [w1] \n"
"mov.b w3, [w1] \n"
"bset OSCCON,#6");

}
int noisev,noisevx,noisec;
// The A/D is set up to sample at 160KHz and interupt every 80KHz
void __attribute__((__interrupt__)) _ADC1Interrupt(void)  /* int every   ADs 80KHz */
{
  int v;

  if (AD1CON2 & 0x80)
		{
		ra=ADC1BUF0+ADC1BUF1;
		ia=ADC1BUF0-ADC1BUF1;
		}
		else
		{
		rb=ADC1BUF8+ADC1BUF9;
		ib=ADC1BUF8-ADC1BUF9;
		}
  if (state<16)
		{ 
          v=ra+rb;
          i2c_buffer[10+(leftright*2)]=v>>8;i2c_buffer[11+(leftright*2)]=v;
          v=0;
		  
		}
		else
		{
		  v=abs(ra-rb)+abs(ia-ib);				// this finds the magnitude of echo by 
												// approximating the real and imag 40Khz components
        }            
  state++;		// Every thing else is chosen by a state machine - updated here

  if (getscan)		// this code is used for waveform gathering (if requested)
	{
      switch (state & 3)
		{
		case 0:echoval[state>>2]=v;
				break;
		case 1:
		case 2:
		case 3:
				echoval[state>>2]+=v;
				break;
		}
	}
  if (state<=16)		// for the first 16 cycles wiggle pins to make 8 pulses
						// could be on the left or right
  {
   if (state==16) AD1CHS0=0x0303;
  
   if (leftright)
     {
	_LATA4=1;
     }
    else
     { 
	_LATA4=0;
     }
      if (state & 1) _LATB4=1; else _LATB4=0;
  }
  else
  {
    if (state==settle) 
		{
          noisev=10000;noisevx=noisec=gotmax=0;max=min=v;echo=0;
		  _LATB7=leftright;
		  _LATA0=0;
        }  // at settle point set background levels
		else
		{_LATB7=0;
			if (state==limit)    // when reached limit of time to wait for echo save results
				{
					if (leftright)
						{
								gotval|=2;
								gecho=echo;gmax=max-min;
                            i2c_buffer[2]=echo>>8;i2c_buffer[3]=echo;
							i2c_buffer[6]=gmax>>8;i2c_buffer[7]=gmax;
							leftright=0;getscan=pendscan & 1;pendscan&=~1;
							AD1CHS0=0x0606;
						}
						else
						{
 							 	gotval|=1;
								gecho=echo;gmax=max-min;
                           i2c_buffer[0]=echo>>8;i2c_buffer[1]=echo;
							i2c_buffer[4]=gmax>>8;i2c_buffer[5]=gmax;
							leftright=1;getscan=pendscan & 2;pendscan&=~2;
							AD1CHS0=0x0707;
						}
					state=0;
				}
				else
				{
				if (state>settle)	// have done waiting for RX to settle
								// look for pulse
					{
					  if (echo)
						{
							if (!gotmax)
								{	
								if (v>max) max=v;
									else
									{  // value has to be big enough to trigger
										if (v<max-16) gotmax=1;
									}
								}
								else
								{
								if (v<min) min=v;
								}
						}
						else
						{
						if (v<noisev)
							{
							if (v>noisevx) noisevx=v;
							noisec++;
							if (noisec==16)
								{
									noisev=noisevx+600;//noisevx<<1;
									if (noisev<70) noisev=70;
									noisevx=noisec=0;
								}
							}
							else
							{
									noisevx=noisec=0;
							}
						if (v>noisev) 
							if (!echo) 
                              {
		  _LATA0=1;
                                echo=state;
                              }
						}
					}
				}
		}
  }


  IFS0bits.AD1IF=0;   // ack interrupt

}


// I2C slave interrupt     DONT touch this without thought
void __attribute__((__interrupt__ , auto_psv)) _SI2C1Interrupt(void)
{
	unsigned char rxv;

	_SI2C1IF=0;
	_SCLREL=1; //@@@@@
     if (_RBF)
     {
         rxv=I2C1RCV;
  		I2C1STATbits.I2COV=0;
     }
   if (_R_W == 0) 
   {
     // data direction is receive from master
       if (_D_A == 1)
       {
         // We have data this time rather than an addreess
		if (I2Cfirst)
		{
			I2Cadress= rxv;
			I2Cfirst=0;
		}
		else
		{
         if (I2C_max_address > I2Cadress) 
			{
			if (rxv!=i2c_buffer[I2Cadress]) i2c_change[I2Cadress]=1;
			i2c_buffer[I2Cadress++] = rxv;
			}
			else
			{
			 if (I2Cadress==128)
				{				
					if (rxv) pendscan=2;
						else pendscan=1;

				}
			}
		}
       }
		else
		{
		I2Cfirst=1;
		}
   }
   else
   {
     // slave required to transmit
         if (I2C_max_address > I2Cadress) 
			{
     		I2C1TRN = i2c_buffer[I2Cadress++];
			}
			else
			{
			 if (I2Cadress==128)
				{				
					I2C1TRN = pendscan | getscan;
					wavepoint=1;
				}
				else
			 if (I2Cadress==129)
				{	
					if (wavepoint<256)
						I2C1TRN=echoval[wavepoint++]/128;
				}
			}
   }
}




char tohexnib(int v)  /* converts a 4 bit nibble to a HEX char */
{
  v&=0xf;
  if (v<=9) return (0x30+v); else return(0x41-10+v);
}





int main ( void )
{
	OSCCON=0x0000;CLKDIV=0x0040;PLLFBD=31;  // FCY = 16MHz

SetupPORTS();

state=0;
leftright=0;
	_SI2C1IF=0;
 	_SI2C1IE=1;	
	i2c_buffer[8]=defaultfreq;i2c_change[8]=0;
	gotval=0;
	wavepoint=0;
lgecho=rgecho=lgmax=rgmax=0;
nl=nr=0;getscan=pendscan=0;inhibit=0;

_AD1IF=0;		// enable AD ints to get the thing going
  _AD1IE=1;


	while (1)		// 99% of the work is done in the A/D and I2C int routines not here!
	{
      if (i2c_change[8])    // if the user has trimmed the freq via I2C update the timer period
	  { PR3=i2c_buffer[8];
		i2c_change[8]=0;
	  }
	  if (gotval)
		{
		  if (gotval & 2)
			{
				lgecho=gecho;
				lgmax=gmax;
				nl=1;
			}
		  	else
			{
				rgecho=gecho;
				rgmax=gmax;
				nr=1;
			}
          gotval=0;
		}
    }    
}


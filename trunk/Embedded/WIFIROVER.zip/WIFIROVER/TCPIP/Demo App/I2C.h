

void I2send(int v);
int I2GET(int ack);
void I2S(void);
void I2SR(void);
void I2P(void);




/************************ HEADERS **********************************/
// SET YOUR ID CODE HERE

#define myidcode 10

#define chanA (CHANNEL_11 + (myidcode-1)*16)
//#define chanA CHANNEL_20 



#include "P2P.h"
#include "MRF24J40.h"
#include "SymbolTime.h"
#include "I2C.h"
#include "hardwareprofile.h"
    
/************************ VARIABLES ********************************/


BYTE myChannel = chanA;
int timetoconnect;
TICK CTick;    
int uctry;
	int myconectionid;
	char running;


#include "typeDef.h"


int lasttag;
TICK txtime;

TICK waketime;
TICK lasttransactiontime;

BYTE BroadcastPacketAR[256];

int BroadcastPacketPoint,instate;
BYTE waveid;
char Broadcast;
unsigned int REQCOUNT=0;

void CheckP2P(void);
void processCMD(BYTE cmdid,BYTE dbytes);

char speed1,speed2,speed3;
int pos1,pos2,pos3;
int lastdir1,lastdir2,lastdir3;
int hist1,hist2,hist3;

extern int adDMAbuf[32] __attribute__((space(dma),aligned(32)));


void initvars(void)
{
speed1=speed2=speed3=0;
pos1=pos2=pos3=lastdir1=lastdir2=lastdir3=0;
hist1=hist2=hist3=0;

}

void __attribute__((interrupt,auto_psv))  _DMA3Interrupt(void)
{
  if (hist3<0) 
	{
  	if (adDMAbuf[6]<hist3) 
		{
			hist3=10;pos3+=lastdir3;
		}
	}
	else
	{
  	if (adDMAbuf[6]>hist3) 
		{
			hist3=-10;pos3+=lastdir3;
		}
	}
  if (hist2<0) 
	{
  	if (adDMAbuf[4]<hist2) 
		{
			hist2=10;pos2+=lastdir2;
		}
	}
	else
	{
  	if (adDMAbuf[4]>hist2) 
		{
			hist2=-10;pos2+=lastdir2;
		}
	}
  if (hist1<0) 
	{
  	if (adDMAbuf[5]<hist1) 
		{
			hist1=10;pos1+=lastdir1;
		}
	}
	else
	{
  	if (adDMAbuf[5]>hist1) 
		{
			hist1=-10;pos1+=lastdir1;
		}
	}

_DMA3IF=0;
}


void setupP2P(void)
{
	   InitSymbolTimer();
    P2PInit();   
    #if defined(PICDEMZ)
        INTCONbits.GIEH = 1;
    #elif defined(EXPLORER16)
    #else
    #endif
	running=0;
    SetChannel(myChannel);
    
    
    /*******************************************************************/
    // Function EnableNewConnection will enable the device to accept
    // request to establish P2P connection from other devices. If a
    // P2P connection has been established, user can choose to call
    // function DisableNewConnection() to reject further request to 
    // establish P2P connection, if it is desired for the application
    /*******************************************************************/
    EnableNewConnection();
    

 }

void CheckP2P(void)
{
    BYTE i;
		 
        /*******************************************************************/
        // Function ReceivedPacket will return a boolean to indicate if a 
        // packet has been received by the transceiver. If a packet has been
        // received, all information will be stored in the rxFrame, structure  
        // of RECEIVED_FRAME.
        /*******************************************************************/
        if( ReceivedPacket() )
        {lasttransactiontime=TickGet();
            /*******************************************************************/
            // If a packet has been received, following code prints out some of
            // the information available in rxFrame.
            /*******************************************************************/
			if (rxFrame.SourceLongAddress[4]==myidcode)
			{
				if (rxFrame.PayLoadSize>0)
					{ 
						processCMD(rxFrame.PayLoad[0],rxFrame.PayLoadSize-1);
					}
			}
            /*******************************************************************/
            // Function DiscardPacket is used to release the current received packet.
            // After calling this function, the stack can start to process the
            // next received frame 
            /*******************************************************************/
            DiscardPacket();
        }
        else
        {
            /*******************************************************************/
            // Macro isDataRequesting returns the boolean to indicate if
            // the Data Request command has received any feedback from its 
            // associated device. If there won't be any message from the associate
            // device to the device with radio off during idle, the RFD device
            // will not required to send out Data Request command, thus the return
            // value of macro isDataRequesting is always FALSE
            /*******************************************************************/
            if( isDataRequesting() == FALSE )
            {
  				if (Broadcast)
				{    
                        FlushTx();
							SlaveID=myidcode;
							for (i=0;i<Broadcast;i++)
								{
									WriteData(BroadcastPacketAR[i]);
								}
				            BroadcastPacket(myPANID, FALSE, FALSE);
							Broadcast=0;
						txtime=TickGet();
                }
                
                #ifdef ENABLE_FREQUENCY_AGILITY
                    /***********************************************************************
                    * AckFailureTimes is the global variable to track the transmission 
                    * failure because no acknowledgement frame is received. Typically,
                    * this is the indication of either very strong noise, or the PAN
                    * has hopped to another channel. Here we call function ResyncConnection
                    * to resynchronize the connection.
                    *   The first parameter is the destination long address of the peer node
                    *   that we would like to resynchronize to.
                    *   The second parameter is the bit map of channels to be scanned
                    *************************************************************************/
                    if( AckFailureTimes > ACK_FAILURE_TIMES )
                    {
                        ResyncConnection(P2PConnections[0].PeerLongAddress, 0x07FFF800);    
                    }
                
                #endif
                
            }   // end of data requesting
	}
}

     

void processCMD(BYTE cmdid,BYTE dbytes)
{
  int tmp;
  int i;
  unsigned int workword;
						switch (cmdid)
						{
							case 0:BroadcastPacketAR[0]=0;   //Ask for Null Echo
									Broadcast=1;  // number in packet
									break;
							case 1:BroadcastPacketAR[0]=1;    //Ask for Led and Switch status Packet
									workword=PORTB;workword=~(workword>>12) &3;
									workword |=((LATB>>6) & 0x30);
									BroadcastPacketAR[1]=workword & 0x33;
									Broadcast=2;  // number in packet
									break;
							case 2:if (dbytes==1)		//Set LEDs
									{
									  _LATB10=!(rxFrame.PayLoad[1] & 1);
									  if (rxFrame.PayLoad[1] & 2) _LATB11=0; else _LATB11=1;
									  BroadcastPacketAR[0]=2;Broadcast=1;  // number in packet
									}
									break;
							case 3:BroadcastPacketAR[0]=3;  // get internal counter
									BroadcastPacketAR[1]=REQCOUNT & 0xff;
									BroadcastPacketAR[2]=(REQCOUNT>>8) & 0xff;REQCOUNT++;
									Broadcast=3;  // number in packet
									break;
							case 4:  // request motor status here 
									 // on receive data send result via MiWi
									  BroadcastPacketAR[0]=4;
									  BroadcastPacketAR[1]=speed1;
									  BroadcastPacketAR[2]=pos1;
									  BroadcastPacketAR[3]=pos1>>8;

									  BroadcastPacketAR[4]=speed2;
									  BroadcastPacketAR[5]=pos2;
									  BroadcastPacketAR[6]=pos2>>8;

									  BroadcastPacketAR[7]=speed3;
									  BroadcastPacketAR[8]=pos3;
									  BroadcastPacketAR[9]=pos3>>8;

									  Broadcast=10;  // number in packet

									break;
							case 5:if (dbytes==1)	// set motor1
									{
									  speed1=(char)rxFrame.PayLoad[1];
									  if (speed1==0) LATD&=~0x0012;
									  if (speed1<0) {LATD|=0x0010;lastdir1=1;}
									  if (speed1>0) {LATD|=0x0002;lastdir1=-1;}
									  BroadcastPacketAR[0]=5;Broadcast=1;  // number in packet
									}
									break;
							case 6:if (dbytes==1)	// set motor2
									{
									  speed2=(char)rxFrame.PayLoad[1];
									  if (speed2==0) LATD&=~0x000C;
									  if (speed2<0) {LATD|=0x0004;lastdir2=1;}
									  if (speed2>0) {LATD|=0x0008;lastdir2=-1;}
									  BroadcastPacketAR[0]=6;Broadcast=1;  // number in packet
									}
									break;
							case 7:if (dbytes==1)	// set motor3
									{
									  speed3=(char)rxFrame.PayLoad[1];
									  if (speed3==0) LATD&=~0x0021;
									  if (speed3<0) {LATD|=0x0001;lastdir3=1;}
									  if (speed3>0) {LATD|=0x0020;lastdir3=-1;}
									  BroadcastPacketAR[0]=7;Broadcast=1;  // number in packet
									}
									break;
							case 8:  
									 if (dbytes==0)	//send bump
									 {
									  BroadcastPacketAR[0]=8;
									  BroadcastPacketAR[1]=0;
									  if (_RG14) BroadcastPacketAR[1]|=1;
									  if (_RG12) BroadcastPacketAR[1]|=2;
									  if (_RG0) BroadcastPacketAR[1]|=4;
									  if (_RG1) BroadcastPacketAR[1]|=8;
									  if (_RD9) BroadcastPacketAR[1]|=16;
									  if (_RD10) BroadcastPacketAR[1]|=32;
									  I2P();Broadcast=2;  // number in packet
									 } 
									break;
							case 9:  
									 if (dbytes==0)	//send ad
									 {
									  BroadcastPacketAR[0]=9;
									  for (i=1;i<=7;i++)
										{BroadcastPacketAR[((i-1)*2)+1]=adDMAbuf[(i-1)];
										 BroadcastPacketAR[((i-1)*2)+2]=adDMAbuf[(i-1)]>>8;
										}
									  for (i=9;i<=10;i++)
										{BroadcastPacketAR[((i-2)*2)+1]=adDMAbuf[(i-1)];
										 BroadcastPacketAR[((i-2)*2)+2]=adDMAbuf[(i-1)]>>8;
										}
									  for (i=15;i<=15;i++)
										{BroadcastPacketAR[((i-6)*2)+1]=adDMAbuf[(i-1)];
										 BroadcastPacketAR[((i-6)*2)+2]=adDMAbuf[(i-1)]>>8;
										}
									  Broadcast=21;  // number in packet
									 } 
									break;
							case 10:  
									 if (dbytes==1)	//request utrasonic wave
									 {
									  I2S();I2send(0xB8);I2send(128);I2send(rxFrame.PayLoad[1]);
									  I2P();
									  BroadcastPacketAR[0]=10;Broadcast=1;  // number in packet
									 } 
									break;
							case 11:  
									 if (dbytes==0)	//request utrasonic wave status
									 {
									  I2S();I2send(0xB8);I2send(128);
									  I2SR();I2send(0xb9);BroadcastPacketAR[0]=11;
									  BroadcastPacketAR[1]=I2GET(0);
									  I2P();Broadcast=2;
									 } 
									waveid=0;
									break;
							case 12:  
									 if (dbytes==0)	//send ultrasonics wave section
									 {
									  I2S();I2send(0xB8);I2send(129);I2SR();I2send(0xb9);
									  BroadcastPacketAR[0]=12;
									  BroadcastPacketAR[1]=waveid++;
									  for (i=1;i<=85;i++)
										{BroadcastPacketAR[i+1]=I2GET(i!=85);
										}
									  I2P();Broadcast=87;  // number in packet
									 } 
									break;
							case 13:  
									 if (dbytes==1)	//send ultrasonics trim
									 {
  									  if ((rxFrame.PayLoad[1]>90) && (rxFrame.PayLoad[1]<rxFrame.PayLoad[1]<110))
										{
									      I2S();I2send(0xB8);I2send(8);I2send(rxFrame.PayLoad[1]);
									      I2P();
									  	  BroadcastPacketAR[0]=13;Broadcast=1;  // number in packet
										}
									 } 
									break;
							case 16:  
									 if (dbytes==0)	//send ultrasonics
									 {
									  I2S();I2send(0xB8);I2send(0);I2SR();I2send(0xb9);
									  BroadcastPacketAR[0]=16;
									  for (i=1;i<=8;i++)
										{BroadcastPacketAR[i]=I2GET(i!=8);
										}
									  I2P();Broadcast=9;  // number in packet
									 } 
									break;
						}
}

        

int main(void)

{   
	long int idel;
    /*******************************************************************/
    // Initialize the system
    /*******************************************************************/

	for (idel=0;idel<0x7ffff;idel++);
    BoardInit(); 
	PHY_RESETn = 1;
	for (idel=0;idel<0x7fff;idel++);
    PHY_RESETn = 0;
	for (idel=0;idel<0x7fff;idel++);
	PHY_RESETn = 1;

   initvars();
	setupP2P();

running=0;
	waketime=lasttransactiontime=txtime=TickGet();uctry=0;
	timetoconnect=0;
    lasttag=0;
	BroadcastPacketPoint=0;instate=0;
	SlaveID=0;Broadcast=0;
	BroadcastPacketAR[0]=0;Broadcast=1;
_DMA3IF=0;
_DMA3IE=1;
    while(1)
    {
		CTick = TickGet();
		CheckP2P();
    }
}


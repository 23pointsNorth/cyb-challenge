

extern volatile unsigned int UltraSonicCycles;
extern volatile char UltraSonicState;
extern volatile unsigned int minADval;
extern volatile unsigned int ECHO;
extern volatile unsigned int lastecho;
extern volatile unsigned int ultracount;


void initultra(void);
